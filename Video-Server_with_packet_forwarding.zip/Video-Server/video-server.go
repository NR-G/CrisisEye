// video-server
package main

import (
	"bufio"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	//"time"

	"github.com/streamrail/concurrent-map-use"
)

var global_map_coords *cmap_use.ConcurrentMap
var serverIP string

//The standards being used here:
//	:5006 is the RTP Video Feed
//	:5007 is the RTCP Control Video Feed messages
//	:4444 is the Port where Gps coords are sent too in the format of:
//		<longitude>,<latitude>
//	:6543 is the where the Webserver is being hosted to pull Gps data from.

//Main Driver
func main() {

	serverIP = "192.168.100.20"

	//Will contain map for string
	//Idea: {<key> == IP, <value> == {long, lat}}
	t_g := cmap_use.New()
	global_map_coords = &t_g

	//Go efficiency has slight annoying behaviours for global vars
	global_map_coords.Set("0.0.0.0", []string{"", "", ""})
	global_map_coords.Remove("0.0.0.0")

	//Basic Packet Forwarding - bool determines if GPS data or not
	go PacketForwarding(serverIP+":5004", "127.0.0.1:6004")
	go PacketForwarding(serverIP+":5005", "127.0.0.1:6005")
	go PacketForwarding(serverIP+":5006", "127.0.0.1:6006")
	go PacketForwarding(serverIP+":5007", "127.0.0.1:6007")

	//Gps related Server logic
	//go CatchGpsCoords(serverIP + ":4444")
	//go DistributeGpsCoords()

	//Forwarding is Async so this works
	fmt.Println("Press Enter to end Packet-Forwarding and exit the program...")
	_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
} //End main

//Catch the GPS Coords
func CatchGpsCoords(ip_source string) {
	t_udp, err := net.ResolveUDPAddr("udp", ip_source)
	ErrorCheck(err)
	listen, err := net.ListenUDP("udp", t_udp)
	ErrorCheck(err)

	fmt.Println("Catching Gps Coordinates at: ", ip_source)

	//Catch the GPS Coords appropriately
	for {
		buffer := make([]byte, 2048)
		_, addr, err := listen.ReadFromUDP(buffer)
		ErrorCheck(err)

		//Store the incoming new GPS Coords and keep going
		s := string(buffer)

		//Pretty printing much?
		//	Java is weird as hell.
		if strings.ContainsAny(s, "\x00") {
			s = strings.Replace(s, "\x00", "", -1) //-1 means no limit on replace
		} //End if

		//Empty case
		if s == "" {
			continue
		} //End if

		ss := strings.Split(s, ",")
		global_map_coords.Set(addr.IP.String(), []string{ss[0], ss[1]})

		fmt.Println(addr.IP.String(), " -> ", s)
	} //End for
} //End CatchGpsCoords()

//Will start the webserver so any http-post request can query for all of the
//	latest Gps connections based on IP address
func DistributeGpsCoords() {

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		io.WriteString(w, "Lol, that's a whole bunch of nope. Try again.")
	})

	http.HandleFunc("/gps_coords", HandleGpsCoords_Request)
	fmt.Println("Webserver listening on " + serverIP + ":6543")
	http.ListenAndServe(serverIP+":6543", nil)
} //End DistributeGpsCoords()

//Returns the entire
func HandleGpsCoords_Request(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		io.WriteString(w, "ERROR")
		return
	}

	//Now let's create the damn JSON
	gmc_iter := global_map_coords.Iter()
	json := "["

	for item := range gmc_iter {
		json += "{"
		json += "\"sourceIP\" : \"" + item.Key + "\","
		json += "\"serverIP\" : \"" + serverIP + "\","
		json += "\"path\" : \"" + item.Val[2] + "\","
		json += "\"latitude\" : \"" + item.Val[1] + "\","
		json += "\"longitude\" : \"" + item.Val[0] + "\","
		json += "\"viewDir\" : \"0\","
		json += "},"
	}
	json = json[:(len(json) - 1)]
	json += "]"

	io.WriteString(w, json)
} //End HandleGpsCoords_Request()

//Forwards the Packet from src ip to dest ip
func PacketForwarding(ip_source string, ip_destination string) {
	src, err := net.ResolveUDPAddr("udp", ip_source)
	ErrorCheck(err)
	t_dest, err := net.ResolveUDPAddr("udp", ip_destination)
	ErrorCheck(err)
	dest, err := net.DialUDP("udp", nil, t_dest)
	ErrorCheck(err)

	listen, err := net.ListenUDP("udp", src) //Listen on src
	ErrorCheck(err)

	fmt.Println("Forwarding Packets from ", ip_source, "too ", ip_destination)
	buffer := make([]byte, 4096)

	count := 0 //DEBUG
	for {
		_, addr, err := listen.ReadFromUDP(buffer)

		if !global_map_coords.Has(addr.IP.String()) {
			global_map_coords.Set(addr.IP.String(), []string{"0.0000", "0.0000"})
		}

		if err != nil {
			fmt.Println(err)
			return
		} else {
			_, _ = dest.Write(buffer)
		}

		//DEBUG ONLY
		count++
		if count%100 == 0 {
			fmt.Println(ip_source, " to ", ip_destination, " -> ", count)
		} //end if
	} //End for
} //PacketForwarding()

//Centralize error checking appropriately
func ErrorCheck(err error) {
	if err != nil {
		fmt.Println(err)
		os.Exit(0)
	} else {
		return
	}
} //End ErrorCheck()
