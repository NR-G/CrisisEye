package com.example.crysiseye200;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;


public class ActivityMain extends AppCompatActivity {

    Button stream;
    Button team;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page);
        stream = (Button) findViewById(R.id.button);
        stream.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View v) {
                setContentView(R.layout.stream_page);
                CameraPreview.mCamera = CameraPreview.getCameraInstance();
                CameraPreview.mPreview = new CameraPreview(ActivityMain.this, CameraPreview.mCamera);
                FrameLayout preview = (FrameLayout) findViewById(R.id.camera_preview);
                preview.addView(CameraPreview.mPreview);
            }
        });
        team = (Button) findViewById(R.id.button2);
    }



}



