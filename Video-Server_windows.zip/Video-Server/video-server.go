// video-server
package main

import (
	"bufio"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"time"

	"github.com/streamrail/concurrent-map-use"
)

var global_map_coords *cmap_use.ConcurrentMap
var gmc_timestamps map[string]time.Time
var global_vid_process map[string]*os.Process
var serverIP string
var path string
var path_file string
var video_port string
var timeout time.Duration

//The standards being used here:
//	Using Static Instances for Video-Feeds:
//		<RTP>-><RTCP>
//			5028->5029
//			5030->5031
//			5032->5033
//			5034->5035
//			5036->5037
//
//	:4444 is the Port where Gps coords are sent too in the format of:
//		<longitude>,<latitude>
//		<orientation>
//	:6543 is the where the Webserver is being hosted to pull Gps data from.
//	:8092 video will streamed off this port for VLC

//Main Driver
func main() {

	serverIP = "192.168.100.20"
	video_port = "8092/"
	path = `C:\Program Files (x86)\VideoLAN\VLC\`
	path_file = `C:\Users\LABEOC\Desktop\VideoSDPFiles\`
	timeout = 5                     //Seconds
	var clean_up time.Duration = 10 //Seconds

	//Will contain map for string
	//Idea: {<key> == IP, <value> == {long, lat, orientation}}
	t_g := cmap_use.New()
	global_map_coords = &t_g

	gmc_timestamps = make(map[string]time.Time)
	global_vid_process = make(map[string]*os.Process)

	//Go efficiency has slight annoying behaviours for global vars
	global_map_coords.Set("0.0.0.0", []string{"", ""})
	global_map_coords.Remove("0.0.0.0")

	//Gps related Server logic
	go CatchGpsCoords(serverIP + ":4444")
	go DistributeGpsCoords()
	go GMC_CleanUp(clean_up) //30 Second interval between cleanups

	//Forwarding is Async so this works
	fmt.Println("Press Enter to end Packet-Forwarding and exit the program...")
	_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
} //End main

//Catch the GPS Coords
func CatchGpsCoords(ip_source string) {
	t_udp, err := net.ResolveUDPAddr("udp", ip_source)
	ErrorCheck(err)
	listen, err := net.ListenUDP("udp", t_udp)
	ErrorCheck(err)

	fmt.Println("Catching Gps Coordinates at: ", ip_source)

	//Catch the GPS Coords appropriately
	for {
		buffer := make([]byte, 2048)
		_, addr, err := listen.ReadFromUDP(buffer)
		ErrorCheck(err)

		//Store the incoming new GPS Coords and keep going
		s := Clean(string(buffer))

		//Empty case
		if s == "" {
			continue
		} //End if

		t_gmc, ok := global_map_coords.Get(addr.IP.String())
		if !ok {
			url := ""
			var cmd *exec.Cmd

			switch addr.IP.String() {
			case "192.168.100.2":
				url = video_port + "s2.ogg"
				arg2 := ":sout=#transcode{vcodec=theo,vb=800,scale=Auto,acodec=none}" +
					":duplicate{dst=http{dst=:8092/s2.ogg},dst=display}"
				arg3 := ":sout-all"
				arg4 := ":sout-keep"
				cmd = exec.Command(path+"vlc", path_file+"stream_0.sdp", arg2, arg3, arg4)
			case "192.168.100.3":
				url = video_port + "s3.ogg"
				arg2 := ":sout=#transcode{vcodec=theo,vb=800,scale=Auto,acodec=none}" +
					":duplicate{dst=http{dst=:8092/s3.ogg},dst=display}"
				arg3 := ":sout-all"
				arg4 := ":sout-keep"
				cmd = exec.Command(path+"vlc", path_file+"stream_1.sdp", arg2, arg3, arg4)
			case "192.168.100.4":
				url = video_port + "s4.ogg"
				arg2 := ":sout=#transcode{vcodec=theo,vb=800,scale=Auto,acodec=none}" +
					":duplicate{dst=http{dst=:8092/s4.ogg},dst=display}"
				arg3 := ":sout-all"
				arg4 := ":sout-keep"
				cmd = exec.Command(path+"vlc", path_file+"stream_2.sdp", arg2, arg3, arg4)
			case "192.168.100.5":
				url = video_port + "s5.ogg"
				arg2 := ":sout=#transcode{vcodec=theo,vb=800,scale=Auto,acodec=none}" +
					":duplicate{dst=http{dst=:8092/s5.ogg},dst=display}"
				arg3 := ":sout-all"
				arg4 := ":sout-keep"
				cmd = exec.Command(path+"vlc", path_file+"stream_3.sdp", arg2, arg3, arg4)
			case "192.168.100.6":
				url = video_port + "s6.ogg"
				arg2 := ":sout=#transcode{vcodec=theo,vb=800,scale=Auto,acodec=none}" +
					":duplicate{dst=http{dst=:8092/s6.ogg},dst=display}"
				arg3 := ":sout-all"
				arg4 := ":sout-keep"
				cmd = exec.Command(path+"vlc", path_file+"stream_4.sdp", arg2, arg3, arg4)
			}
			ErrorCheck(cmd.Start())
			global_vid_process[addr.IP.String()] = cmd.Process

			gmc_timestamps[addr.IP.String()] = time.Now()
			global_map_coords.Set(addr.IP.String(), []string{"", "", "", url})
			t_gmc, _ = global_map_coords.Get(addr.IP.String())
		}

		if strings.ContainsAny(s, ",") {
			ss := strings.Split(s, ",")
			global_map_coords.Set(addr.IP.String(), []string{ss[0], ss[1], t_gmc[2], t_gmc[3]})
			gmc_timestamps[addr.IP.String()] = time.Now()
			fmt.Println(addr.IP.String(), " -> ", s)
		} else {
			global_map_coords.Set(addr.IP.String(), []string{t_gmc[0], t_gmc[1], s, t_gmc[3]})
		}
	} //End for
} //End CatchGpsCoords()

//Will start the webserver so any http-post request can query for all of the
//	latest Gps connections based on IP address
func DistributeGpsCoords() {

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		io.WriteString(w, "Lol, that's a whole bunch of nope. Try again.")
	})

	http.HandleFunc("/gps_coords", HandleGpsCoords_Request)
	fmt.Println("Webserver listening on " + serverIP + ":6543")
	http.ListenAndServe(serverIP+":6543", nil)
} //End DistributeGpsCoords()

//Returns the entire
func HandleGpsCoords_Request(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Access-Control-Allow-Headers", "True")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	//Now let's create the damn JSON
	gmc_iter := global_map_coords.Iter()
	json := "["

	for item := range gmc_iter {
		json += "{"
		json += "\"sourceIP\" : \"" + item.Key + "\","
		json += "\"serverIP\" : \"" + serverIP + "\","
		json += "\"path\" : \"" + item.Val[3] + "\","
		json += "\"latitude\" : \"" + item.Val[1] + "\","
		json += "\"longitude\" : \"" + item.Val[0] + "\","
		json += "\"viewDir\" : \"" + item.Val[2] + "\""
		json += "},"
	}

	if json != "[" {
		json = json[:(len(json) - 1)]
	}
	json += "]"

	io.WriteString(w, json)
} //End HandleGpsCoords_Request()

//Cleanup Go-routine that'll clear out the GMC at set interval
func GMC_CleanUp(interval time.Duration) {
	ticker := time.NewTicker(time.Second * interval)
	go func() {
		for _ = range ticker.C {
			fmt.Println("Cleaning up some memory...")
			for item := range global_map_coords.Iter() {
				old_time := gmc_timestamps[item.Key]
				new_time := old_time.Add(time.Second * timeout)

				if time.Now().After(new_time) {
					global_map_coords.Remove(item.Key)
					global_vid_process[item.Key].Kill()
					delete(gmc_timestamps, item.Key)
					delete(global_vid_process, item.Key)
				} //End if
			} //End for
		} //End for
	}() //End Anon()
	time.Sleep(time.Millisecond * 500)
} //End GMC_CleanUp()

//Centralize error checking appropriately
func ErrorCheck(err error) {
	if err != nil {
		fmt.Println(err)
		os.Exit(0)
	} else {
		return
	}
} //End ErrorCheck()

//Because I hate Java
func Clean(data string) string {
	if strings.ContainsAny(data, "\x00") {
		return strings.Replace(data, "\x00", "", -1) //-1 means no limit on replace
	} else {
		return data
	} //End else
} //Enc Clean
